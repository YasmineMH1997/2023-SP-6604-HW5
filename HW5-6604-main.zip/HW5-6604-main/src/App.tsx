import React, { useRef, useState } from 'react';
import logo from './logo.svg';
import './App.css';
//import {Graph} from 'react-d3-graph'
import { TextField, Button, Table, TableCell, TableHead, TableRow } from '@mui/material';
import { ForceGraph } from './d3obj';
import { schemeCategory10 } from "d3-scale-chromatic";

const accessFreq = [
  {item: "D1", freq:[0.65,0.25,0.17,0.22,0.31,0.24]},
  {item: "D2", freq:[0.44,0.62,0.41,0.40,0.42,0.46]},
  {item: "D3", freq:[.35,.44,.50,.25,.45,0.37]},
  {item: "D4", freq:[.31,.15,.10,.60,.09,0.10]},
  {item: "D5", freq:[.51,.41,.43,.38,.71,.20]},
  {item: "D6", freq:[.08,.07,.05,0.15,.20, 0.62]},
  {item: "D7", freq:[.38,.32,.37,.33,.40,.32]},
  {item: "D8", freq:[.22,.33,.21,.23,.24,.17]},
  {item: "D9", freq:[.18,.16,.19,.17,.24,.21]},
  {item: "D10", freq:[.09,.08,.06,.11,.12,0.09]}
]

const data = {
  nodes: [
      { id: "M1",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]}, 
      { id: "M2",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]},  
      { id: "M3",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]}, 
      { id: "M4",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]}, 
      { id: "M5",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]},  
      { id: "M6",  items: [{item:"D1",isOriginal: true},{item:"D5", isOriginal: false},{item: "D2", isOriginal:false}]}, 
    ],
  links: [
    { source: "M1", target: "M2" },
    { source: "M1", target: "M3" },
    { source: "M2", target: "M4" },
    { source: "M3", target: "M4" },
    { source: "M4", target: "M5" },
    { source: "M4", target: "M6" },
    { source: "M5", target: "M6" },
  ],
};





const customerViewGen = (node) => {
  return (<div style={{"width": "500px", "height": "200px"}}><Table>
        <TableHead>
          <TableRow> 
            <TableCell>
              Data
            </TableCell>
          </TableRow>
          {
            node.data.map(d => <TableRow><TableCell>{d.item}</TableCell></TableRow>)
          }
        </TableHead>
    </Table></div>)
}

const myConfig = {
  nodeHighlightBehavior: true,
  node: {
    color: "lightgreen",
    size: 500,
    highlightStrokeColor: "blue",
    viewGenerator: customerViewGen
  },
  link: {
    highlightColor: "lightblue",
  },
};

const onClickNode = function(nodeId) {
  window.alert(`Clicked node ${nodeId}`);
};

const onClickLink = function(source, target) {
  window.alert(`Clicked link between ${source} and ${target}`);
};


function App() {
  const currentSAFSvg = useRef(null);
  const currentDAFNSvg = useRef(null);
  const currentDCGSvg = useRef(null);

  
  const [textSpace, setTextSpace] = useState("");

 /* type Edge = {
    source: string;
    target: string;
  }
  
  type Graph = {
    links: Edge[];
  }*/
  const DCG = () => {
    const biconnected = BiConnectedComponents(data)
    console.log("biconnected",biconnected)
    const nodeNames: string[][] = [];
   for (const component of biconnected) {
  const nodes = new Set<string>();
  for (const edge of component) {
    nodes.add(edge.source);
    nodes.add(edge.target);
  }
  nodeNames.push(Array.from(nodes));
}


const nodeColors = nodeNames.map(() => {
  const index = Math.floor(Math.random() * schemeCategory10.length);
  return schemeCategory10[index];
});

console.log("node",nodeColors);
console.log("names",nodeNames);
    const original = SAF(false);
  
    console.log("original",original.links)
    const svg= ForceGraph({ nodes: original.nodes, links:data.links }, {nodeTitle: (d) => `${d.id} : ${d.items.map(i => i.item)}`},nodeNames,nodeColors)
    if(currentDCGSvg.current){
      currentDCGSvg.current.innerHTML=""
      currentDCGSvg.current.appendChild(svg)
    }
  }

  
  const BiConnectedComponents = (graph: Graph) => {
    const visited: Record<string, boolean> = {};
    const ids: Record<string, number> = {};
    const low: Record<string, number> = {};
    const parent: Record<string, string | null> = {};
    const stack: string[] = [];
    const components: Edge[][] = [];
    const componentLookup: Record<string, boolean> = {}; // Keep track of which components have already been added
    const sourceTargetMap: Record<string, number> = {};
    
    const dfs = (node: string) => {
      visited[node] = true;
      ids[node] = low[node] = Object.keys(ids).length;
      stack.push(node);
  
      for (const edge of graph.links) {
        if (edge.source !== node && edge.target !== node) {
          continue;
        }
  
        const neighbor = edge.source === node ? edge.target : edge.source;
  
        if (!visited[neighbor]) {
          parent[neighbor] = node;
          dfs(neighbor);
          low[node] = Math.min(low[node], low[neighbor]);
  
          if (ids[node] <= low[neighbor]) {
            const component: Edge[] = [];
  
            while (true) {
              const current = stack.pop()!;
              component.push({ source: parent[current]!, target: current });
  
              if (current === neighbor) {
                break;
              }
            }
  
            // Check if component has already been added, if not add it
            const componentKey = component.map(({ source, target }) => `${source}-${target}`).join(';');
            if (!componentLookup[componentKey]) {
              components.push(component);
              componentLookup[componentKey] = true;
            }
          }
        } else if (neighbor !== parent[node]) {
          low[node] = Math.min(low[node], ids[neighbor]);
        }
        
        // Count the number of times a node appears as a source or target
        if (node in edge) {
          const key = `${edge.source}-${edge.target}`;
          sourceTargetMap[key] = (sourceTargetMap[key] || 0) + 1;
        }
      }
    };
  
    dfs("M1");
    
// Filter out edges where both nodes are present in multiple components
const nodeToRemove: Record<string, boolean> = {};
for (const component of components) {
  const nodeCount: Record<string, number> = {};

  for (const edge of component) {
    const { source, target } = edge;
    nodeCount[source] = (nodeCount[source] || 0) + 1;
    nodeCount[target] = (nodeCount[target] || 0) + 1;
  }

  for (const edge of component) {
    const { source, target } = edge;
    const sourceKey = `${source}-${target}`;
    const targetKey = `${target}-${source}`;

    if ((sourceTargetMap[sourceKey] || sourceTargetMap[targetKey]) > 1 && !nodeToRemove[source]) {
      nodeToRemove[source] = true;
    }

    if ((sourceTargetMap[sourceKey] || sourceTargetMap[targetKey]) > 1 && !nodeToRemove[target]) {
      nodeToRemove[target] = true;
    }
  }
}

// Create a new set of components with only the desired nodes
const filteredComponents: Edge[][] = [];
for (const component of components) {
  const filteredEdges: Edge[] = [];

  for (const edge of component) {
    const { source, target } = edge;

    // Check if source or target is present in more than one component
    const sourceCount = components.filter(comp => comp.some(e => e.source === source || e.target === source)).length;
    const targetCount = components.filter(comp => comp.some(e => e.source === target || e.target === target)).length;

    // If source/target is present in only one component or is the first edge in this component, keep it
    if ((sourceCount === 1 && targetCount === 1) || filteredEdges.length === 0 || nodeToRemove[source] || nodeToRemove[target]) {
      filteredEdges.push(edge);
    }
  }

  // Add filtered component to filteredComponents array
  if (filteredEdges.length > 0) {
    filteredComponents.push(filteredEdges);
  }
}

//console.log("filteredComponents", filteredComponents);
return filteredComponents;
};
  

  

  

  var old = []
  const DAFN = () => {
    const replicas = SAF(false);
    old = SAF2();
    console.log("old", old);
   // console.log("hi");
    var updatedReplicas = [];
    var LinksDuringRelocationPeriod = []
    // Loop over the links and check for duplicated items between neighboring replicas
    data.links.forEach(link => {
      const nodeA = replicas.nodes.find(node => node.id === link.source);
    console.log("nodeA", nodeA);
      const nodeB = replicas.nodes.find(node => node.id === link.target);
     console.log("nodeB", nodeB);
       
      const duplicatedItemsA = nodeA.items.filter(item => nodeB.items.some(bItem => bItem.item === item.item));
      const duplicatedItemsB = nodeB.items.filter(item => nodeA.items.some(bItem => bItem.item === item.item));
     console.log("A",duplicatedItemsA)
     console.log("B",duplicatedItemsB)

  // Remove items with least frequency values from each node
  duplicatedItemsA.forEach(dItemA => {
    const dItemB = duplicatedItemsB.find(item => item.item === dItemA.item);
    if (dItemB) {
      if (dItemA.isOriginal) {
        nodeB.items = nodeB.items.filter(item => item.item !== dItemB.item);
        // Remove the same item from old nodeB
        const oldNodeB = old.nodes.find(node => node.id === nodeB.id);
        oldNodeB.items = oldNodeB.items.filter(item => item.item !== dItemB.item);
      } else if (dItemA.freq < dItemB.freq) {
        nodeA.items = nodeA.items.filter(item => item.item !== dItemA.item);
        // Remove the same item from old nodeA
        const oldNodeA = old.find(node => node.id === nodeA.id);
        oldNodeA.items = oldNodeA.items.filter(item => item.item !== dItemA.item);
      } else {
        nodeB.items = nodeB.items.filter(item => item.item !== dItemB.item);
        // Remove the same item from old nodeB
        const oldNodeB = old.find(node => node.id === nodeB.id);
        oldNodeB.items = oldNodeB.items.filter(item => item.item !== dItemB.item);
      }
    }
  });
 // console.log("old zeft22", old);
  
      // Check if nodeA is already in updatedReplicas
      const indexA = updatedReplicas.findIndex(node => node.id === nodeA.id);
      if (indexA !== -1) {
        // Replace the existing node with the latest version
        updatedReplicas[indexA] = nodeA;
      } else {
        // Add nodeA to updatedReplicas
        updatedReplicas.push(nodeA);
      }
  
      // Check if nodeB is already in updatedReplicas
      const indexB = updatedReplicas.findIndex(node => node.id === nodeB.id);
      if (indexB !== -1) {
        // Replace the existing node with the latest version
        updatedReplicas[indexB] = nodeB;
      } else {
        // Add nodeB to updatedReplicas
        updatedReplicas.push(nodeB);
      }
    });

    var CopyOfReplicas = updatedReplicas
    var checkNeighborsWithSameItem = []
    // Loop over each node in old and update corresponding node in updatedReplicas
old.forEach(oldNode => {
  const updatedNode = updatedReplicas.find(node => node.id === oldNode.id);
  const existingItems = new Set(updatedNode.items.map(item => item.item));

  // Add additional items to updatedNode until it has N items and no repeated items
  let count = updatedNode.items.length;
  oldNode.items.forEach(oldItem => {
    if (count >= textSpace) {
      return;
    }
    var flag = 0
    if (!existingItems.has(oldItem.item)) {
    /*  data.links.forEach(link => {
            if(link.source===updatedNode.id)
                 
                    CopyOfReplicas.forEach(check => {
                          
                        if(check.id=== link.target)
                        {
                       //// console.log("check.items",check.items)
                        checkNeighborsWithSameItem=  check.items.find(itemCheck => itemCheck.item === oldItem.item)
                        //console.log("check",checkNeighborsWithSameItem)
                        }
                        if(checkNeighborsWithSameItem)
                            flag=1

                    })

      })*/
     // if(flag===0){
      updatedNode.items.push(oldItem);
      count++;}
   // }
  });
});

// Update the replicas array with the updated nodes
replicas.nodes = updatedReplicas;
  
    // Update the replicas array with the updated nodes
   // replicas.nodes = updatedReplicas;
    console.log("updated replicas",updatedReplicas)
  
 //  data.nodes = updatedReplicas
    const svg = ForceGraph({ nodes: data.nodes, links: data.links }, {nodeTitle: (d) => d.id},null,null);
  
 if (currentDAFNSvg.current) {
  currentDAFNSvg.current.innerHTML = "";
  currentDAFNSvg.current.appendChild(svg);
    }
  

  };


  const SAF = (flag) => {

    /*// Loop over the nodes and filter the original items
    data.nodes.forEach((node) => {
    const originalItems = node.data.filter((item) => item.isOriginal);
    console.log(`Original items for node ${node.id}: `, originalItems);
  });*/
  const nodeFreqs = [];
  
  for (let i = 0; i < data.nodes.length; i++) {
    accessFreq.sort((a, b) => b.freq[i] - a.freq[i]);
    //console.log(`Sorted frequencies for node M${i+1}:`);
    const nodeObj = {
      id: `M${i+1}`,
      freqs: [],
    };
    //Allocate frequencies according to the space available (Ci--> input)
    for (let j = 0; j < parseInt(textSpace); j++) {
      const freqObj = {
        item: accessFreq[j].item,
        freq: accessFreq[j].freq[i],
      };
      nodeObj.freqs.push(freqObj);
    }
    nodeFreqs.push(nodeObj);
  }
  
  //console.log("Node frequencies:", nodeFreqs);
  
  const replicas = [];

  for (let i = 0; i < nodeFreqs.length; i++) {
    const nodeObj = {
      id: nodeFreqs[i].id,
      items: nodeFreqs[i].freqs//.map(freqObj => freqObj.item)
    };
    replicas.push(nodeObj);
  }
  
  //console.log("Replicas:", replicas);
  data.nodes = replicas
  if(flag){
    const svg= ForceGraph({ nodes: data.nodes, links:data.links }, {nodeTitle: (d) => `${d.id} : ${d.items.map(i => i.item)}`},null,null)
      if(currentSAFSvg.current){
        currentSAFSvg.current.innerHTML=""
        currentSAFSvg.current.appendChild(svg)
      }}
    return data
  }

  const SAF2 = () => {

    /*// Loop over the nodes and filter the original items
    data.nodes.forEach((node) => {
    const originalItems = node.data.filter((item) => item.isOriginal);
    console.log(`Original items for node ${node.id}: `, originalItems);
  });*/
  const nodeFreqs = [];
  const tmp = accessFreq
  for (let i = 0; i < data.nodes.length; i++) {
    tmp.sort((a, b) => b.freq[i] - a.freq[i]);
    //console.log(`Sorted frequencies for node M${i+1}:`);
    const nodeObj = {
      id: `M${i+1}`,
      freqs: [],
    };
    //Allocate frequencies according to the space available (Ci--> input)
    for (let j = 0; j < tmp.length; j++) {
      const freqObj = {
        item: tmp[j].item,
        freq: tmp[j].freq[i],
      };
      nodeObj.freqs.push(freqObj);
    }
    nodeFreqs.push(nodeObj);
  }
  
  //console.log("Node frequencies:", nodeFreqs);
  
  const replicas = [];

  for (let i = 0; i < nodeFreqs.length; i++) {
    const nodeObj = {
      id: nodeFreqs[i].id,
      items: nodeFreqs[i].freqs//.map(freqObj => freqObj.item)
    };
    replicas.push(nodeObj);
  }
  
  console.log("final", replicas);
  //data.nodes = replicas

    return replicas
  }
  
  return (
    <>
    <div>
    <Button color={"primary"} onClick={() => SAF(true)}  variant={'contained'}>E-SAF+</Button>
    <Button color={"primary"} onClick={DAFN} variant={'contained'}>E-DAFN+</Button>
    <Button color={"primary"} onClick={DCG} variant={'contained'}>E-DCG+</Button>
    </div>
    <div>
    <TextField onChange={(event) => setTextSpace(event.target.value)} id="outlined-basic" label="Space Available" variant="outlined" />

    <div style={{height:"100%", width:"100%", padding: "20px"}} id="divid" ref={currentSAFSvg}></div>

    <div style={{height:"100%", width:"100%", padding: "20px"}} id="divid" ref={currentDAFNSvg}></div>
    <div style={{height:"100%", width:"100%", padding: "20px"}} id="divid" ref={currentDCGSvg}></div>
  </div>
  </>
  );
}

export default App;
